# BizTrend AI

An intelligent business analytics and predictive decision support system using machine learning and adaptive forecasting.

Single-business deployment, batch processing, daily/weekly/monthly analysis. The system **supports** decisions; it never executes transactions or purchasing commitments.

## Roadmap (built step by step)

| Step | Scope | Status |
|------|-------|--------|
| 1 | Project scaffold, data layer (CSV import, validation, manual entry, aggregation), sample data, tests | Done |
| 2 | Sales Intelligence + Financial Intelligence | Pending |
| 3 | Demand Forecasting (adaptive model selection) | Pending |
| 4 | Inventory Intelligence | Pending |
| 5 | Anomaly Detection | Pending |
| 6 | AI Business Assistant (rule-based, from model outputs) | Pending |
| 7 | Streamlit UI tying it all together | Pending |

## Setup

```bash
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m biztrend.sample_data # writes data/sample_*.csv
pytest
```

## Data format

Transactions CSV (headers are matched flexibly, e.g. `qty`, `item`, `type`):

`date, record_type (sale|expense), product, category, quantity, unit_price, amount, notes`

- `amount` is derived from `quantity * unit_price` if missing.
- Invalid rows are dropped and reported, never silently.

Optional products CSV for inventory: `product, unit_cost, stock_on_hand, lead_time_days`.

Your real data lives in `data/transactions.csv` and `data/products.csv`, which are git-ignored.
